

''' Função cadastro dos pets'''

#def checaCadastroPet(...)


#def cadastroPET(...)


#def buscaPET(...)


#def apagaCadastroPET(...)




#if __name__ == .......:

db_pets = [
    {
        'ID':'01-00001-2024',
        'nome':'Max',
        'Tipo':'cachorro',
        'Ano':'2024'
    },
    {
        'ID':'02-00002-2018',
        'nome':'Miau',
        'Tipo':'gato',
        'Ano':'2018'
    },
]

#testes...